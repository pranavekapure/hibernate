package com.ct.hibernate.module;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	@Override
	public String toString() {
		return "Product [proId=" + proId + ", proName=" + proName + ", proDes=" + proDes + "]";
	}
	@Id
		private int proId;
		private String proName;
		private String proDes;
		
		public Product() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getProId() {
			return proId;
		}
		public void setProId(int proId) {
			this.proId = proId;
		}
		public String getProName() {
			return proName;
		}
		public void setProName(String proName) {
			this.proName = proName;
		}
		public String getProDes() {
			return proDes;
		}
		public void setProDes(String proDes) {
			this.proDes = proDes;
		}
		
}
