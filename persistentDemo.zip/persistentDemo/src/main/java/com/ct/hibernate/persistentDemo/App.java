package com.ct.hibernate.persistentDemo;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.ct.hibernate.module.Product;

public class App 
{
	public static SessionFactory sessionFactory;
	public static void main(String...anc) {
		
		
		
		
		
		
	
		Configuration configuration = new Configuration().configure();
        ServiceRegistry serviceRegistry= new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
         // builds a session factory from the service registry
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);  
        Session session =sessionFactory.openSession();
        session.beginTransaction();
	
        
        
        
        
        
		 
		session.getTransaction().commit(); 
		 
		
		
		session.close();
		
		
		
		
	}
}
